/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacion.danny;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class EvaluacionDanny {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String Nombre = "";
        String Grado = "";
        
        System.out.println("ingrese su Nombre");
        Scanner D1 = new Scanner(System.in);
        Nombre = D1.nextLine();
        
        System.out.println("ingrese su Grado");
        Scanner D2 = new Scanner(System.in);
        Grado = D2.nextLine();
        
        System.out.println("mi nombre es " + Nombre + Grado); 
        
        
      
        
        
        
    }
    
}
